document.addEventListener("DOMContentLoaded", function() {
    const loginForm = document.getElementById("login-form");

    loginForm.addEventListener("submit", function(e) {
        e.preventDefault();

        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;

        // Simples validação de login (adapte conforme necessário)
        if (username === "admin" && password === "admin") {
            alert("Login bem-sucedido!");
            window.location.href = "dashboard.html"; // Redireciona para a página principal após o login
        } else {
            alert("Usuário ou senha incorretos.");
        }
    });
});
