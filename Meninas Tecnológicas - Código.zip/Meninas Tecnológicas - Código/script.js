document.getElementById('subscribe-banner').addEventListener('click', function(event) {
    event.preventDefault();
    document.querySelector('#subs').scrollIntoView({ 
        behavior: 'smooth' 
    });
});

document.addEventListener('DOMContentLoaded', function () {
    const clouds = document.querySelectorAll('.cloud');
    let clickCount = 0;
    let startTime = Date.now();
    let balloonsAdded = false;

    clouds.forEach(cloud => {
        cloud.addEventListener('click', function () {
            cloud.classList.add('pulsing');
            setTimeout(() => {
                cloud.classList.remove('pulsing');
            }, 3000); 

            clickCount++;
            if (!balloonsAdded && clickCount >= 4) { 
                addBalloonsAndSpeechBubble();
                balloonsAdded = true;
            }
        });
    });

    function addBalloonsAndSpeechBubble() {
        const header = document.getElementById('header');

        const balloon1 = createBalloon('img/Balão.png', 'Balão', '20%', '67%', '5%');
        header.appendChild(balloon1);
        animateBalloon(balloon1, '20%', '67%', '5%');

        const balloon2 = createBalloon('img/Balão.png', 'Balão', '85%', '60%', '3%');
        header.appendChild(balloon2);
        animateBalloon(balloon2, '85%', '60%', '3%');

        const balloon3 = createBalloon('img/Balão.png', 'Balão', '35%', '10%', '3%');
        header.appendChild(balloon3);
        animateBalloon(balloon3, '35%', '10%', '3%');

        const speechBubble = createSpeechBubble('img/Balão de fala.png', 'Diálogo', '57%', '27%', '8%');
        header.appendChild(speechBubble);
        animateSpeechBubble(speechBubble, '57%', '27%', '8%');
    }

    function createBalloon(src, alt, bottom, right, width) {
        const newBalloon = document.createElement('img');
        newBalloon.src = src;
        newBalloon.alt = alt;
        newBalloon.classList.add('balão', 'new-balao');
        newBalloon.style.width = width;

        newBalloon.style.bottom = '-100px';
        newBalloon.style.right = '-100px';
        
        return newBalloon;
    }

    function animateBalloon(balloon, bottom, right, width) {
        void balloon.offsetWidth;

        balloon.style.display = 'block';
        balloon.style.transition = 'all 2s ease';

        balloon.style.bottom = bottom;
        balloon.style.right = right;
        balloon.style.width = width;
    }

    function createSpeechBubble(src, alt, bottom, right, width) {
        const newBubble = document.createElement('img');
        newBubble.src = src;
        newBubble.alt = alt;
        newBubble.classList.add('dialogo');
        newBubble.style.width = width;
        newBubble.style.bottom = bottom;
        newBubble.style.right = right;
        newBubble.style.opacity = '0';
        return newBubble;
    }

    function animateSpeechBubble(speechBubble, bottom, right, width) {
        void speechBubble.offsetWidth;

        speechBubble.style.display = 'block';
        speechBubble.style.transition = 'opacity 2s ease';
        
        setTimeout(() => {
            speechBubble.style.opacity = '1';
        }, 1600); 
    }
});

document.getElementById("saibaMais").addEventListener("click", function(event) {
    window.location.href = 'about/about.html';
});